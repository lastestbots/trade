from .line_profiler import main

if __name__ == '__main__':
    main()
